*************
Tmux segments
*************

.. automodule:: powerline.segments.tmux
   :members:
